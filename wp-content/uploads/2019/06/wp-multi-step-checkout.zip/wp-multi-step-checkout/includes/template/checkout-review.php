<table class="shop_table">
    <thead>
        <tr>
            <th class="product-name">Datos de env&iacute;o</th>
            <th class="product-total"></th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Nombre y Apellido</td>
            <td class="order-review-name"></td>
        </tr>
        <tr>
            <td>Correo electr&oacute;nico</td>
            <td class="order-review-email"></td>
        </tr>
        <tr>
            <td>Direcci&oacute;n</td>
            <td class="order-review-address"></td>
        </tr>
    </tbody>
    
</table>
<? if (is_plugin_active( 'payu-custom-checkout/payu-custom-checkout.php' )): ?>
    
    <?php $path = get_site_url().'/wp-content/plugins/payu-custom-checkout/includes/methods/assets'; ?>

  
<? endif; ?>
<table class="shop_table">
    <thead>
        <tr>
            <th class="product-name">Metodo de pago</th>
            <th class="product-total"></th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>
              <div style="display: none;" class="payment_review" id="efectivo_label">EFECTIVO</div>
              <div style="display: none;" class="payment_review" id="tc_label">TARJETA DE CR&Eacute;DITO</div>
              <div style="display: none;" class="payment_review" id="pse_label">PSE</div>
            </td>
            <td>      
              <img style="display: none;" class="payment_review"src="<?php echo $path; ?>\visa.png" alt="" id="visa_img">
              <img style="display: none;" class="payment_review" src="<?php echo $path; ?>\mastercard.png" alt="" id="mastercard_img">
              <img style="display: none;" class="payment_review" src="<?php echo $path; ?>\codensa.png" alt="" id="codensa_img">
              <img style="display: none;" class="payment_review" src="<?php echo $path; ?>\dinners_club.png" alt="" id="dinners_club_img">
              <img style="display: none;" class="payment_review" src="<?php echo $path; ?>\amercian_express.png" alt="" id="amex_img">
              <img style="display: none;" class="payment_review" src="<?php echo $path; ?>\baloto.png" alt="" id="baloto_img">
              <img style="display: none;" class="payment_review" src="<?php echo $path; ?>\efecty.png" alt="" id="efecty_img">
              <img style="display: none;" class="payment_review" src="<?php echo $path; ?>\bancodebogota.png" alt="" id="bank_referenced_1_img">
              <img style="display: none;" class="payment_review" src="<?php echo $path; ?>\bancolombia.png" alt="" id="bank_referenced_2_img">
              <img style="display: none;" class="payment_review" src="<?php echo $path; ?>\su-red.png" alt="" id="others_cash_img">
              <img style="display: none;" class="payment_review" src="<?php echo $path; ?>\bank.png" alt="" id="pse_image_img">
            </td>
        </tr>

    </tbody>
    
</table>

<script>
jQuery(function($) {

  $( document ).ready(function() {
    
      $('.wpmc-tab-number[number="2"]').click(function (){
        
        validateOrderReview();

      });
  });


  function validateOrderReview(){

    $('.payment_review').hide();

    var name = $('#billing_first_name');

    var email = $('#billing_email');

    var address = $('#billing_address_1');

    var address_extra = $('#billing_address_2');

    var stateInput = $('#billing_state').select2('data');

    var cityInput = $('#billing_city').select2('data');

    $('.order-review-name').html(name.val());

    $('.order-review-email').html(email.val());

    $('.order-review-address').html(address.val()+' '+address_extra.val()+' ('+cityInput[0].text+' - '+stateInput[0].text+')');

    var paymentMethod = $('#payment_method').val();

    if (paymentMethod == 'payu_tc') {
      alert(2);
      var tc_form = $("#wc-payu_tc-cc-form").serializeArray();

      $(tc_form).each(function( index, element ) {
        
        if(element.value == '' && element.name != 'id_type' && element.name != 'id_number'){
          alert('Porfavor complete el metodo de pago');
          $('.wpmc-tab-number[number="1"]').trigger('click');
          return false;
          
        }
      });

      var franchise = $('#franchise').val();

      if(franchise== 'CODENSA'){

        var idType = $('#id_type').val();

        var idNumber = $('#id_number').val();

        if (idType == '' || idNumber == '') {
            alert('Porfavor complete el metodo de pago');
            $('.wpmc-tab-number[number="1"]').trigger('click');
            return false;
        }


      }

      $('#tc_label').show();
      $('#'+franchise.toLowerCase()+'_img').show();

    }else if(paymentMethod == 'payu_efectivo'){

        var efectiveMethod = $('#efectivo-select').val();

        if (efectiveMethod == '') {

            alert('Porfavor complete el metodo de pago');
            $('.wpmc-tab-number[number="1"]').trigger('click');
            return false;
        }

        $('#efectivo_label').show();

        $('#'+efectiveMethod.toLowerCase()+'_img').show();

    }else if(paymentMethod == 'payu_trasferencia_bancaria'){


        var pse_form = $("#wc-payu_tc-cc-form").serializeArray();

        $(pse_form).each(function( index, element ) {
          
          if(element.value == ''){
            alert('Porfavor complete el metodo de pago');
            $('.wpmc-tab-number[number="1"]').trigger('click');
            return false;
          }
        });

        $('#pse_label').show();

        $('#pse_image_img').show();
    }else{

        alert('Porfavor seleccione un metodo de pago');  
        $('.wpmc-tab-number[number="1"]').trigger('click');
        return false;
    }
  }
});


</script>